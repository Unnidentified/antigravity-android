# Antigravity Android — Handoff

## Contents of `antigravity-android-handoff.zip`
- `HANDOFF.md` — this handoff document
- `antigravity-android/` — complete native Kotlin Android Gradle project (with `.git` initialized on `main`, clean working tree, commit `05b2b0e`)
- `dist/antigravity-debug.apk` — compiled debug APK (`app-debug.apk`, 5.9 MB) ready to install or attach to a GitHub prerelease

## What Was Built
A production-ready, single-activity native Kotlin Android WebView wrapper for `https://antigravity.google.com`:

- **Project & Build (`Kotlin DSL .kts`):**
  - Package: `com.antigravity.wrapper`, App name: **Antigravity**
  - `minSdk = 26`, `targetSdk = 35`, `compileSdk = 35`, AGP `8.7.3`, Kotlin `2.0.21`, Gradle wrapper `8.9`
  - Dark Material 3 theme, edge-to-edge `WindowInsetsCompat` (`systemBars | displayCutout | ime`), dark minimalist adaptive launcher icon (with monochrome layer), and AndroidX `SplashScreen`.
- **WebView & Google Auth Support:**
  - JavaScript, DOM Storage, database storage, and hardware acceleration enabled.
  - `CookieManager` configured for first-party and third-party cookies with disk flushing on page finish, pause, and stop.
  - `UserAgentSanitizer` strips `; wv` and `Version/x.y` from the WebView User-Agent so `accounts.google.com` does not return `403 disallowed_useragent`.
  - `UrlRouter` + `AntigravityWebViewClient` keep `antigravity.google.com` and Google auth domains in-app, open external links in Chrome Custom Tabs (with browser fallback), and delegate non-HTTP schemes (`mailto:`, `tel:`, `intent://`) to system intents.
- **Native UX & Capabilities:**
  - `OnBackPressedCallback` routes system back to `webView.goBack()` (or exits fullscreen views).
  - Thin top `LinearProgressIndicator` and `SwipeRefreshLayout` gated on `webView.scrollY == 0`.
  - Native file uploads via `WebChromeClient.onShowFileChooser` + `ActivityResultContracts.OpenMultipleDocuments`.
  - Authenticated file downloads via `DownloadHandler` wired to Android's `DownloadManager`.
  - Clean native offline/error screen with **Retry** button on main-frame `onReceivedError`.
  - `INTERNET`, `ACCESS_NETWORK_STATE`, and optional `CAMERA`/`RECORD_AUDIO` permissions in `AndroidManifest.xml`, with origin-checked runtime permission handling in `onPermissionRequest`.

## Verification Completed
- `./gradlew assembleDebug testDebugUnitTest` — **BUILD SUCCESSFUL**
- Unit tests: **7/7 passing** (`UrlRouterTest`: 4/4, `UserAgentSanitizerTest`: 3/3)
- Output APK: `dist/antigravity-debug.apk` (5.9 MB)

## Commit Message Convention (Saved Globally & In-Repo)
- Global skill **`commit-message-style`** has been saved for future sessions.
- `antigravity-android/AGENTS.md` documents the same rule in-repo:
  - Always very short, formatted as `xxx: xxx (#prnumber)` (e.g., `feat: add android wrapper (#1)`).

## Remaining Steps: Create Repo & Publish Prerelease
GitHub repo creation from the previous session was blocked only because that conversation was not inside a Project. To finish:

### Option A — In a New Antigravity Project Session
1. Create a **Project** in Antigravity and upload `antigravity-android-handoff.zip`.
2. Ask the agent to:
   - Extract `antigravity-android-handoff.zip`
   - Create a GitHub repository (e.g., `antigravity-android`) via `create_github_repository`
   - Push `main` from `antigravity-android/`
   - Create a prerelease (e.g., `v1.0.0-alpha.1`) attaching `dist/antigravity-debug.apk`

### Option B — Locally via `gh` CLI
```bash
unzip antigravity-android-handoff.zip
cd antigravity-android

# 1. Create GitHub repo and push main
gh repo create antigravity-android --public --source=. --remote=origin --push

# 2. Create prerelease with the compiled debug APK attached
gh release create v1.0.0-alpha.1 ../dist/antigravity-debug.apk \
  --prerelease \
  --title "Antigravity v1.0.0-alpha.1" \
  --notes "Initial prerelease of the native Kotlin Android WebView wrapper for https://antigravity.google.com."
```

## Notes for Rebuilding Locally
- `local.properties` was omitted from the zip (it is machine-specific). Android Studio generates it automatically, or set `ANDROID_HOME` / create `local.properties` with `sdk.dir=/path/to/android-sdk`.
- Build & test commands:
  ```bash
  ./gradlew assembleDebug
  ./gradlew testDebugUnitTest
  ```
